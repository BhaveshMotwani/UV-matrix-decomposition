task1.txt:
	This is the output for task1 with command
		python uv.py ./mat.dat 5 5 2 10
	In this task, remember not to write the output to any files. Use standard output to print them instead.

t2_output.txt:
	This is the output file for task2 with command
		bin\spark-submit .\als-orig.py .\mat.dat 5 5 4 10 5 t2_output.txt
